
local name = "Kennedy"

print("Hello " .. name)



